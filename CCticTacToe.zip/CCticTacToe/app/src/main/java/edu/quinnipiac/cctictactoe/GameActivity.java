package edu.quinnipiac.cctictactoe;

import android.content.Intent;
import android.os.Bundle;
import android.os.Debug;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

// Christian Colaiezzi Assignment 1  2/18/2021
public class GameActivity extends AppCompatActivity implements View.OnClickListener{

    private int dimension = 5;
    private Button[][] buttons = new Button[dimension][dimension];

    String check = "";

    private boolean p1Turn = true;

    private int runner;
    private String playerName;
    private int p1Points;
    private int p2Points;
    private TextView Player1;

    private TextView p1Score;
    private TextView p2Score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_activity);

        Intent intent = getIntent();
        playerName = (String) intent.getStringExtra("name");
        Player1 = (TextView) findViewById(R.id.text_view_p1);
        Player1.setText(playerName + ": " + p1Points);
        p1Score = findViewById(R.id.text_view_p1);
        p2Score = findViewById(R.id.text_view_p2);

        for (int i = 0; i < dimension; i++) {
            for (int j = 0; j < dimension; j++) {

                String buttonID = "button_" + i + j;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                buttons[i][j] = findViewById(resID);
                buttons[i][j].setOnClickListener(this);
            }
        }


        Button reset = findViewById(R.id.reset);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Reset();
            }
        });
    }

    private void Reset() {
        p1Points = 0;
        p2Points = 0;
        ScoreText();
        CleanBoard();
    }

    @Override
    public void onClick(View view) {

        if (!((Button) view).getText().toString().equals("")) {
            return;
        }

        if (p1Turn) {
            ((Button) view).setText("X");
            p1Turn = false;
        }
        if (!p1Turn && runner != 12) {
            Random random = new Random();
            int i, j;
            i = random.nextInt(dimension);
            j = random.nextInt(dimension);

            aa:
            for (int k = 0; k < dimension * dimension; k++) {

                while (!(buttons[i][j].getText().toString().equals(""))) {
                    i = random.nextInt(dimension);
                    j = random.nextInt(dimension);
                }
                buttons[i][j].setText("O");
                break aa;
            }
        }

        runner++;
        String winner = checkForWin();

            if (winner == "X") {
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        p1Win();
                    }
                }, 1000);
            } else if (winner == "O"){
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        p2Win();
                    }
                }, 1000);
            } else if (runner == 13) {
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    draw();
                }
            }, 1000);
        } else {
            p1Turn = true;
        }
    }

    private String checkForWin(){
        int winLength = 4;

        for(int i = 0; i < dimension; i++){
            for(int j = 0; j < dimension; j++){
                String player = buttons[i][j].getText().toString();
                boolean winRow = true, winCol = true, winDia1 = true, winDia2 = true;

                for(int x = 1; x < winLength; x++){
                    if(i+x >= dimension || buttons[i+x][j].getText().toString() != player){
                        winRow = false;
                    }
                    if(j+x >= dimension || buttons[i][j+x].getText().toString() != player){
                        winCol = false;
                    }
                    if((i + x >= dimension) || (j + x >= dimension) || buttons[i+x][j+x].getText().toString() != player){
                        winDia1 = false;
                    }
                    if((i + x >= dimension) || (j - x < 0) || buttons[i+x][j-x].getText().toString() != player) {
                        winDia2 = false;
                    }
                }
                if((winRow  || winCol || winDia1 || winDia2) && player !=""){
                    return player;
                }
            }
        }
        return"";
    }

    private void p1Win() {
        p1Points++;
        Toast.makeText(this, "Player 1 wins!", Toast.LENGTH_SHORT).show();
        ScoreText();
        CleanBoard();
    }

    private void p2Win() {
        p2Points++;
        Toast.makeText(this, "CPU wins!", Toast.LENGTH_SHORT).show();
        ScoreText();
        CleanBoard();
    }

    private void draw() {
        Toast.makeText(this, "Draw!", Toast.LENGTH_SHORT).show();
        CleanBoard();
    }

    private void ScoreText() {
        p1Score.setText(playerName + p1Points);
        p2Score.setText("CPU: " + p2Points);

    }

    private void CleanBoard() {
        for (int i = 0; i < dimension; i++) {
            for (int j = 0; j < dimension; j++) {
                buttons[i][j].setText("");
            }
        }
        runner = 0;
        p1Turn = true;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putInt("runner", runner);
        outState.putInt("p1points", p1Points);
        outState.putInt("p2points", p2Points);
        outState.putBoolean("p1Turn", p1Turn);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        runner = savedInstanceState.getInt("runner");
        p1Points = savedInstanceState.getInt("p1points");
        p2Points = savedInstanceState.getInt("p2points");
        p1Turn = savedInstanceState.getBoolean("p1Turn");
    }

}
